package com.gamingroom;

public class Entity {
	
	// Private Variables
	private long id;
	private String name;
	
    // Private constructor to prevent instantiation
	private Entity() {}
	
	public Entity(long id, String name) {
		this();
		this.id = id;
		this.name =name;
		
	}
	
	// Getter method
	public long getId() {
		return id;
	}
	
	// Getter method
	public String getName() {
		return name;
	}
	
	@Override
	public String toString() {
		return "Game [id=" + id + ", name=" + name + "]";
	}
}
