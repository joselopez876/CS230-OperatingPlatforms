package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A singleton service for the game engine
 * 
 * @author coce@snhu.edu
 */
public class GameService {

	/**
	 * A list of the active games
	 */
	private static List<Game> games = new ArrayList<Game>();

	/*
	 * Holds the next game, player, and team identifier
	 */
	private static long nextGameId = 1;
	private static long nextPlayerId = 1;
	private static long nextTeamId = 1;
	
	/*
	 * This Singleton instance makes sure there is only one instance of the GameService existing in memory at any time
	 * With this we can have the single instance manage a list of many games 
	 */
	private static GameService instance;
	

	//Private constructor so class cannot be instantiated
	private GameService() {}
	
	/*
	 * getInstance() method checks if the instance already exists and controls access to the instance
	 * All this together makes our basic singleton instance
	 */
	
	public static GameService getInstance() {
		if (instance == null) {
			instance = new GameService();
		}
		
		return instance; 
	}


	public Game addGame(String name) {

		// a local game instance
		Game game = null;
		
		// A iterator for the games list
		Iterator<Game> myIterator = games.iterator();	
		
		// While loop iterates through the games list and checks if there are more items in list
		while (myIterator.hasNext()) {
			Game currentGame = myIterator.next();      // Gets next item in games list
			if (currentGame.getName().equals(name)) {  // Checks if the current game name matches any game with the same name 
				game = currentGame;                    // Assigns current game to the local variable
				break;                                 // Breaks loop
 			}
			
		}

		// if not found, make a new game instance and add to list of games
		if (game == null) {
			game = new Game(nextGameId++, name);
			games.add(game);
		}

		// return the new/existing game instance to the caller
		return game;
	}

	/**
	 * Returns the game instance at the specified index.
	 * <p>
	 * Scope is package/local for testing purposes.
	 * </p>
	 * @param index index position in the list to return
	 * @return requested game instance
	 */
	Game getGame(int index) {
		return games.get(index);
	}
	
	/**
	 * Returns the game instance with the specified id.
	 * 
	 * @param id unique identifier of game to search for
	 * @return requested game instance
	 */
	public Game getGame(long id) {

		// a local game instance
		Game game = null;
		
		// A iterator for the games list
		Iterator<Game> myIterator = games.iterator();	
		
		// While loop iterates through the games list and checks if there are more items in list
		while (myIterator.hasNext()) {
			Game currentGame = myIterator.next();      // Gets next item in games list
			if (currentGame.getId() == id) {   		   // Checks if the current game id matches any game with the same id
				game = currentGame;					   // Assigns current game to the local variable
				break;                                 // Breaks loop
			}
		}
		
		return game;
	}

	/**
	 * Returns the game instance with the specified name.
	 * 
	 * @param name unique name of game to search for
	 * @return requested game instance
	 */
	public Game getGame(String name) {

		// a local game instance
		Game game = null;

		/*
		 * These iterator patterns help us read through all the items in the games list
		 * Making sure that each item in the list isn't passed
		 * With this we are able to iterate through the list to find a game with the same name or id
		 * If there is a match it is assigned to the local variable and returns it
		 */
		
		// A iterator for the games list
		Iterator<Game> myIterator = games.iterator();
		
		// While loop iterates through the games list and checks if there are more items in list
		while (myIterator.hasNext()) {
			Game currentGame = myIterator.next();       // Gets next item in games list
			if (currentGame.getName().equals(name)) {   // Checks if the current game name matches any game with the same name
				game = currentGame;                     // Assigns current game to the local variable
				break;									// Breaks loop
			}
			
		}
		
		return game;
	}

	/**
	 * Returns the number of games currently active
	 * 
	 * @return the number of games currently active
	 */
	public int getGameCount() {
		return games.size();
	}
	
	// Gets next player Id
	public long getNextPlayerId() {
		return nextPlayerId++;
	}
	
	// Gets next team Id
	public long getNextTeamId() {
		return nextTeamId++;
	}
}
