package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A simple class to hold information about a team
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a team is
 * created.
 * </p>
 * @author coce@snhu.edu
 *
 */
public class Team extends Entity {
	
	// A list to hold players in the team
	private static List<Player> players = new ArrayList<>();
	
	// Public constructor
	public Team(long id, String name) {
		super(id,name); 				 // Call to superclass constructor (Entity)
	}
	
	// Method to add a player to the team
	public Player addPlayer(String name) {
		
		// a local player instance
		Player player = null;
		
		// A iterator for the team list
		Iterator<Player> myIterator = players.iterator();	
		
		// While loop iterates through the team list and checks if there are more items in list
		while (myIterator.hasNext()) {
			Player currentPlayer = myIterator.next();      // Gets next item in games list
			if (currentPlayer.getName().equals(name)) {    // Checks if the current team name matches any team with the same name 
				player = currentPlayer;                    // Assigns current team to the local variable
				break;                                     // Breaks loop
 			}
			
		}

		// if not found, make a new game instance and add to list of teams
		if (player == null) {
            player = new Player(GameService.getInstance().getNextPlayerId(), name);
            players.add(player);

		}
		
		// return the new/existing team instance to the caller
		return player;
	}
	
	@Override
	public String toString() {
		return "Team [id=" + getId() + ", name=" + getName() + "]";
	}
}
