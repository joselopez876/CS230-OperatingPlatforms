package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A simple class to hold information about a game
 * 
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a game is
 * created.
 * </p>
 * 
 * @author coce@snhu.edu
 *
 */
public class Game extends Entity{
	
	// A list to hold teams in the game
	private static List<Team> teams = new ArrayList<>();
	
	// Public constructor
	public Game(long id, String name) {
		super(id,name); 
	}
	
	// Method to add a team to the game
	public Team addTeam(String name) {
		
		// a local team instance
		Team team = null;
		
		// A iterator for the team list
		Iterator<Team> myIterator = teams.iterator();	
		
		// While loop iterates through the team list and checks if there are more items in list
		while (myIterator.hasNext()) {
			Team currentTeam = myIterator.next();      // Gets next item in games list
			if (currentTeam.getName().equals(name)) {  // Checks if the current team name matches any team with the same name 
				team = currentTeam;                    // Assigns current team to the local variable
				break;                                 // Breaks loop
 			}
			
		}

		// if not found, make a new game instance and add to list of teams
		if (team == null) {
            team = new Team(GameService.getInstance().getNextTeamId(), name);
            teams.add(team);
		}
		
		// return the new/existing team instance to the caller
		return team;
	}
		
	@Override
	public String toString() {
		return "Game [id=" + getId() + ", name=" + getName() + "]";
	}
}
